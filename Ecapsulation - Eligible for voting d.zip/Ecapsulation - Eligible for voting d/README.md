# Eligible-for-voting-With-Encapsulation
 Encapsulation example
