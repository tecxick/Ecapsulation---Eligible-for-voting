﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Ecapsulation___Eligible_for_voting
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("To check the Eligibility, Enter your age");
            Console.Write("Age : ");
            int age = int.Parse(Console.ReadLine());

            Check_Eligibility check = new Check_Eligibility();

            check.setAge(age);
            bool el =  check.getEligibility();

            if(el)
            {
                Console.WriteLine("You're Eligible");
            }
            else
            {
                Console.WriteLine("You're not Eligible");
            }

            Console.ReadLine();

        }
    }
}
