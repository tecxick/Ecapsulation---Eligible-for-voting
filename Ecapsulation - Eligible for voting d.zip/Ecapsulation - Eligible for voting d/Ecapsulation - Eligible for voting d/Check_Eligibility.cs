﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecapsulation___Eligible_for_voting
{
    class Check_Eligibility
    {
        private int age;
        private bool eligibility;
        public void setAge(int age_user)
        {
            age = age_user;
        }

        public bool getEligibility()
        {
            check_Eligibility(age);
            return eligibility;
        }

        private bool check_Eligibility(int age)
        {
            

            if(age>18)
            {
                eligibility = true;
            }
            else
            {
                eligibility = false;
            }

            return eligibility;
        }
    }
}
